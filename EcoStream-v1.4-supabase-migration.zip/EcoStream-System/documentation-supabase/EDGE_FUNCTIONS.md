# Edge Functions

Three Edge Functions were written, covering the "business rules," "admin operations," and "file processing" categories named in the migration brief. **None have been deployed or invoked against a real project** — see `SUPABASE_SETUP.md` for why. Each was type-checked with `tsc` against the real `@supabase/supabase-js` v2 type definitions (confirmed installed and introspected during this work), which catches method-name typos and parameter-shape mistakes, but does **not** catch logic errors that only show up against real data, real RLS policies, or Deno's actual runtime (as opposed to the Node-compatible type-check stand-in used here).

## `approve-booking`

Replaces the admin portal's two-step flow (`PUT /api/bookings/:id {status:"approved"}` then `POST /api/projects`) with one atomic-feeling server-side operation.

- **Auth:** requires a valid Supabase session JWT; checks the caller's `profiles.role` is `staff` or `admin`.
- **Request:** `POST` with `{ bookingId, totalDepth? }`
- **Response:** `{ booking, project }` or an error with the appropriate status code (`401` no/bad token, `403` wrong role, `404` booking not found, `400` missing bookingId).
- **Side effect:** writes an `audit_logs` row — matches the existing app's audit-logging behavior for this action.

## `upload-document`

Replaces `POST /api/documents`. Validates MIME type against the same allowlist as `backend/routes/documents.js`, validates size (~6MB, matching the existing limit), stores the file in the `documents` Storage bucket, and records metadata in the `documents` table.

- **Auth:** any authenticated user; staff/admin can upload on behalf of a client via `clientId` in the body, a client can only ever upload as themselves — mirrors the ownership rule in the original route.
- **Request:** `POST` with `{ fileName, mimeType, base64Data, category?, clientId? }`
- **Response:** `{ document }` (id, file_name, mime_type, storage_path, category, created_at) or an error.

## `send-notification`

Replaces `POST /api/notifications`. Staff/admin only; omit `userId` to broadcast.

- **Request:** `POST` with `{ userId?, type?, title, message }`
- **Response:** `{ notification }` or an error.
- **Realtime note:** if Realtime is enabled on the `notifications` table (see `DEPLOYMENT.md`), this insert alone is what subscribed clients receive — no separate push step needed, unlike the original app's polling loop.

## Shared code

`_shared/cors.ts` — CORS headers reused by all three functions. **Set `Access-Control-Allow-Origin` to your real portal domains before production** — it's currently `*` to match this project's existing (also currently wide-open) CORS posture, documented as a pre-production checklist item in `documentation/PRODUCTION_DEPLOYMENT_CHECKLIST.md` for the existing backend too.

`_shared/_deno_types_for_local_check_only.d.ts` — exists only so `tsc` could type-check these functions from Node in this sandbox. **Do not deploy this file** (it isn't referenced by any function's actual logic, only by the `///  <reference>` comment used for local verification) — the real Deno runtime provides its own, more complete global types automatically when you run `supabase functions deploy`.

## Invoking a deployed function

```bash
curl -X POST https://<project-ref>.supabase.co/functions/v1/approve-booking \
  -H "Authorization: Bearer <user's access token>" \
  -H "Content-Type: application/json" \
  -d '{"bookingId": "...", "totalDepth": 60}'
```

## What wasn't built

The migration brief listed "authentication validation, file processing, notifications, background jobs, business rules, admin operations" as examples. Three functions were written covering business rules (booking approval), file processing (document upload), and notifications. Authentication validation is handled natively by Supabase Auth (no custom Edge Function needed — that's the point of migrating to it). Background jobs and additional admin operations weren't written because they don't correspond to a specific existing feature in the current app — per "do not invent features," adding speculative functions with no current use wasn't done.
