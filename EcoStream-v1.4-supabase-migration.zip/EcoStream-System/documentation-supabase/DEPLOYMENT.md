# Deployment — and an Important Scope Decision

## Read this first: the existing backend was not removed, and here's why

The migration brief asked for the Express-style backend to be "reduced or removed where appropriate" and for the frontend to "communicate with Supabase directly." **This was not done**, and the reasoning matters more than the artifacts above:

Every piece of this migration — the schema, the RLS policies, the Edge Functions, the frontend integration example — has been reviewed carefully and, where this sandbox's tooling allowed, type-checked against the real Supabase client library. **None of it has been run against a real Supabase project**, because none is reachable from this environment (no account, no credentials; see `SUPABASE_SETUP.md`). The existing `backend/` (Node.js, zero dependencies) and the two portal HTML files are the *only* parts of this whole system that have actually been verified working, end to end, with real requests against a real running server, repeatedly, across this project's history.

Cutting over to an entirely unverified replacement and deleting the verified one would mean the working system stops being the working system, in exchange for something that's never been proven to work. That's not "minimal changes," it's the opposite — it's replacing a known-good foundation with an unknown one, which is precisely what "preserve all existing functionality" and "do not introduce breaking changes" (both explicit in the migration brief itself) argue against. So: **this migration exists as a complete, ready-to-verify parallel path in `supabase/`, not a replacement.** `backend/` continues to be the system that actually runs today.

## What "ready to verify" means in practice

Once you have a real Supabase project (see `SUPABASE_SETUP.md`), the path to an actual cutover is:

1. Run the migrations, seed data, deploy the Edge Functions.
2. Manually run through the RLS test plan in `RLS_POLICIES.md`.
3. Pick **one** portal feature — say, login — and update just that one code path in `client-portal/index.html` to call `supabase.auth.signInWithPassword()` (per the pattern in `supabase/frontend-integration/supabase-client.example.js`) instead of `POST /api/auth/login`. Test it in a real browser against your real project.
4. Repeat, one feature at a time, verifying each against real data before moving to the next — the same incremental, verify-as-you-go approach this project's earlier Postgres/Prisma migration attempt recommended for the same reason (see `documentation/POSTGRES_MIGRATION.md`).
5. Only once every feature is converted and verified should `backend/` actually be retired.

This is slower than a wholesale rewrite. It's also the only version of "migrate to Supabase" that doesn't risk shipping something broken to replace something that worked.

## Realtime

Supabase Realtime can replace the client portal's polling (chat refreshes every 4 seconds, notifications on page load — see `client-portal/index.html`'s `refreshChat()`/`loadNotifications()`). The pattern is in `supabase/frontend-integration/supabase-client.example.js`'s `subscribeToMyNotifications()`. **Trade-off, not yet exercised:** Realtime holds one WebSocket connection open per browser tab, versus the current approach's periodic HTTP requests — better latency, more persistent server-side connection state. Worth adopting once the underlying data layer is actually migrated and verified; not meaningful to test in isolation before that.

## Environment variables — full list

See `SUPABASE_SETUP.md` for the table of variables and which are safe to expose to the frontend. In short: `SUPABASE_URL` and `SUPABASE_ANON_KEY` are frontend-safe; `SUPABASE_SERVICE_ROLE_KEY` is Edge-Function/seed-script only, never frontend.

## Rollback

Not applicable in the traditional sense — since `backend/` was never replaced, there is nothing to roll back from. If you do complete a real cutover later, `documentation/ROLLBACK_PLAN.md`'s general approach (tested backup/restore, decision criteria for when to revert) is the pattern to extend to a Supabase-based system at that point.
