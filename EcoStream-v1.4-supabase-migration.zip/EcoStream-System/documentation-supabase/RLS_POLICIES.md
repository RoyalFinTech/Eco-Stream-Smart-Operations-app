# Row Level Security Policies

Full SQL: `supabase/migrations/0002_rls_policies.sql`. Every table has RLS enabled; a table with RLS on and no matching policy denies access entirely by default, so nothing is "publicly readable unless intentional" — the one deliberate exception is `cms` (site content, meant to be readable by anyone including a logged-out visitor).

## Policy summary, by table

| Table | Read | Write |
|---|---|---|
| `profiles` | Own row, or any row if staff/admin | Own row (self-update); any row if admin |
| `projects` | Own (client), all (staff/admin) | Staff/admin only |
| `bookings` | Own (client), all (staff/admin) | Client can create/cancel own; staff/admin can update status |
| `payments` | Own (client), all (staff/admin) | Staff/admin only |
| `notifications` | Own or broadcast (`user_id is null`), all (staff/admin) | Staff/admin can create; recipient can mark read |
| `tickets` | Own (client), all (staff/admin) | Client can create/reply to own; staff/admin can reply, change status, delete. A trigger blocks a client from changing `status` themselves (see below) |
| `documents` | Own (client), all (staff/admin) | Any authenticated user can record their own upload; staff/admin can delete |
| `chat_messages` | Own thread (client), all (staff/admin) | Client can message own thread; staff/admin any thread |
| `equipment`, `expenses` | Staff/admin only | Staff/admin only |
| `cms` | **Everyone**, including logged-out | Admin only |
| `audit_logs` | Admin only | No policy — inserts happen via `SECURITY DEFINER` functions/Edge Functions, never directly from a client request |

## Why a trigger, not just a policy, for `tickets.status`

RLS policies are row-level (can this user touch this row at all?), not column-level (can this user change this specific column?). The original app lets a client reply to their own ticket but only staff/admin can change its status. A plain `update` policy can't express "you may update this row, but only certain columns" — so `prevent_client_status_change()` is a `before update` trigger that raises an exception if a non-staff/admin caller's update would change `status`. This is the standard Postgres pattern for column-level restrictions under RLS.

## Helper functions

`is_staff_or_admin()` and `is_admin()` — both `security definer stable` SQL functions that check the calling user's role via a `profiles` lookup. `security definer` means they run with the privileges of the function owner (not the caller), which is what lets a policy check role without needing its own separate RLS grant on `profiles` for the check itself; `stable` tells Postgres's query planner the result won't change within a single statement, allowing it to cache/optimize the repeated calls.

## Suggested test plan (not run here — no database to run it against)

Once you have a real project, before trusting these with production data:

1. Create two client accounts (A and B) and one staff account via the seed script or manually.
2. As A, confirm `select * from projects` returns only A's projects, not B's.
3. As A, attempt `update tickets set status = 'resolved' where client_id = auth.uid()` — confirm it's rejected by the trigger.
4. As staff, confirm the same update succeeds.
5. As B, attempt to `select` or `insert` into A's storage folder path — confirm both are rejected.
6. As an anonymous (logged-out) request, confirm `select * from cms` succeeds and `select * from projects` returns nothing.
7. As staff (not admin), attempt `select * from audit_logs` — confirm it's rejected (audit logs are admin-only, matching the original app's `requireRole("admin")` on that one endpoint specifically).

## Verification status

Every policy was reviewed manually against Supabase's documented RLS syntax and the schema in `DATABASE_SCHEMA.md`. **None have been executed against a real database** — there is no Postgres instance (local or Supabase-hosted) reachable from this sandbox to run the test plan above against. Treat this policy set as a well-reasoned first draft that needs the test plan actually run, not as verified-safe.
