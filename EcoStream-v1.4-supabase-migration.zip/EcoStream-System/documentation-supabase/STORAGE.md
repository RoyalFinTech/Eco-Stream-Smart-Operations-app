# Storage

## Bucket created: `documents` only

The migration brief suggested four buckets (`profile-images`, `documents`, `uploads`, `public-assets`). Only `documents` was created — it's the only one matching an actual existing feature (borehole reports, water-test results, contracts; currently `backend/routes/documents.js` + `backend/lib/storage/`). There is no profile-picture upload, no separate generic "uploads" concept, and no public marketing-asset serving anywhere in the current app. Per "do not invent features," speculative buckets for non-existent functionality weren't created. If you build one of those features later, follow the same pattern in `supabase/migrations/0003_storage_buckets.sql` — it's a two-part addition (an `insert into storage.buckets` row, plus 2-3 policies on `storage.objects`).

## Path convention

Files are stored at `{owner_profile_id}/{document_id}.{ext}` — for example `3fa85f64-.../7c9e6679-....pdf`. The owner's UUID as the first path segment is what the RLS policies check via `storage.foldername(name)[1]`, so ownership is derivable from the path alone without an extra table join on every read.

## RLS policies on `storage.objects`

Three policies scoped to `bucket_id = 'documents'` (full policy language in `supabase/migrations/0003_storage_buckets.sql`, plain-language summary here):

1. **Read:** the file's owner (path prefix matches their own user id) or any staff/admin.
2. **Upload:** only into your own folder (path prefix must match your own user id) — you cannot write into another user's folder even if you knew their UUID.
3. **Delete:** staff/admin only.

## Signed URLs vs. public access

The bucket is created with `public: false` — no file is fetchable by a bare URL. Downloads go through `supabase.storage.from('documents').createSignedUrl(path, expirySeconds)`, which returns a time-limited URL (see `supabase/frontend-integration/supabase-client.example.js`'s `downloadDocument()`). This replaces the original app's `GET /api/documents/:id` endpoint, which returned the file as base64 inside a JSON response — signed URLs are the more standard, more bandwidth-efficient pattern for this, and avoid loading the entire file into a JSON payload and JS memory.

## Verification status

**Not verified against a real bucket** — same blocker as everywhere else in this migration (no Supabase project reachable from this sandbox). The policy SQL was reviewed against Supabase's documented `storage.objects` RLS patterns and the `storage.foldername()` helper function's documented behavior, not tested with a real upload/download round trip.
