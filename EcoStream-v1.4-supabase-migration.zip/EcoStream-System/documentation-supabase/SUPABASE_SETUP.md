# Supabase Setup Guide

**Status of everything in this document: written and internally consistent, but not run against a real Supabase project.** This environment has no Supabase account, no project credentials, and no Docker (so even `supabase start`'s local dev stack can't run here). Every command below is what you'd run yourself; none of them have been executed in this sandbox. See `documentation/BLOCKERS.md` for the equivalent honesty note on the earlier Postgres/Prisma migration attempt — this is the same situation, one level further along.

## What was actually verified in this sandbox, and how

Node's own package-registry access started working partway through this project (confirmed by an actual `npm install @supabase/supabase-js`, not just a metadata lookup) — this is new and wasn't true earlier in this project's history. That let me do real, meaningful verification that wasn't possible before:
- Installed the real `@supabase/supabase-js` v2.110.8 and introspected its actual exported methods and TypeScript definitions, rather than writing code from memory/training data.
- Type-checked every Edge Function and the frontend integration example against those real type definitions using `tsc` — all pass with zero errors, confirming method names, parameter shapes, and call chaining are correct.
- Ran `supabase/seed.js` against a fake project URL and confirmed it fails with a network error (`fetch failed`) rather than a code error — proving the script is structurally sound up to the point of an actual network call.

**What remains unverified, and why:** a real Supabase project requires account creation (I can't sign up for services on your behalf), and even with a project, this sandbox's browser tool is blocked from every CDN host tested (esm.sh, jsdelivr, unpkg all return `403`) even though Node's own registry access works — so I also couldn't test loading `@supabase/supabase-js` in an actual browser page. Both of these need a human to complete.

## Step-by-step setup (for you to run)

### 1. Create a Supabase project
Go to [supabase.com](https://supabase.com), create a project, and note down (Project Settings → API):
- `SUPABASE_URL` (Project URL)
- `SUPABASE_ANON_KEY` (anon/public key — safe for the frontend)
- `SUPABASE_SERVICE_ROLE_KEY` (service role key — **never** expose this to the frontend; Edge Functions and the seed script only)

### 2. Run the database migrations
Install the Supabase CLI (this works from any machine with real npm access — confirmed installable, version 2.110.0, during this project's own verification):
```bash
npm install -g supabase
supabase login
supabase link --project-ref <your-project-ref>
supabase db push
```
This applies, in order: `supabase/migrations/0001_init_schema.sql`, `0002_rls_policies.sql`, `0003_storage_buckets.sql`. **Recommendation, not verified here:** run this against a staging project first, not production, and manually spot-check a few RLS policies (see `RLS_POLICIES.md`'s test plan) before trusting it with real data.

### 3. Seed demo data
```bash
cd supabase
SUPABASE_URL=<your-url> SUPABASE_SERVICE_ROLE_KEY=<your-service-role-key> node seed.js
```
Creates the same four demo accounts documented elsewhere in this repo (`admin@ecostream.gm`, `engineer@ecostream.gm`, `lamin@example.com`, `fatou@example.com` — all with their existing documented passwords) plus two sample projects and one booking.

### 4. Set Edge Function secrets
```bash
supabase secrets set SUPABASE_URL=<your-url>
supabase secrets set SUPABASE_SERVICE_ROLE_KEY=<your-service-role-key>
```
`SUPABASE_ANON_KEY` doesn't need to be set as a secret — Supabase automatically injects it (and `SUPABASE_URL`) into every Edge Function's environment already. The explicit `supabase secrets set SUPABASE_URL` above is only needed if you want to be certain it's available; check your CLI version's behavior.

### 5. Deploy Edge Functions
```bash
supabase functions deploy approve-booking
supabase functions deploy upload-document
supabase functions deploy send-notification
```
See `EDGE_FUNCTIONS.md` for what each one does and how to invoke it.

### 6. Point the frontend at your project
See `supabase/frontend-integration/supabase-client.example.js` and `DEPLOYMENT.md` for how the existing portals would be updated — **not done automatically**, since the existing portals are tested and working and this migration doesn't touch them (see `DEPLOYMENT.md` for why).

## Required environment variables

| Variable | Where it's used | Safe to expose to frontend? |
|---|---|---|
| `SUPABASE_URL` | Everywhere | Yes |
| `SUPABASE_ANON_KEY` | Frontend, Edge Functions (user-context client) | Yes — it's the public key, protected by RLS |
| `SUPABASE_SERVICE_ROLE_KEY` | `supabase/seed.js`, Edge Functions (admin-context client) | **No — never.** Bypasses RLS entirely. |
