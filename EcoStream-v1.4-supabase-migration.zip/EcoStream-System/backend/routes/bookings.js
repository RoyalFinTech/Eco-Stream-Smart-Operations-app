const db = require("../lib/db");
const { genId } = require("../lib/auth");
const { sendJSON, authenticate, requireRole } = require("../lib/router");
const { requireFields } = require("../lib/validate");

function register(router) {
  // ---------- POST /api/bookings (client books drilling / requests a site survey) ----------
  router.post("/api/bookings", authenticate, (req, res) => {
    const { package: pkg, drillingLocation, areaType, purpose, paymentPlan, requestType } = req.body;
    requireFields(req.body, ["drillingLocation"]);
    const booking = db.collection("bookings").insert({
      id: genId("b"),
      clientId: req.user.id,
      requestType: requestType || "drilling", // "drilling" | "site-survey"
      package: pkg || "standard",
      drillingLocation,
      areaType: areaType || "residential",
      purpose: purpose || "drinking",
      paymentPlan: paymentPlan || "full",
      status: "pending",
      submittedAt: new Date().toISOString().slice(0, 10),
      createdAt: new Date().toISOString(),
    });
    sendJSON(res, 201, { booking });
  });

  // ---------- GET /api/bookings ----------
  router.get("/api/bookings", authenticate, (req, res) => {
    const all = db.collection("bookings").all();
    const visible = req.user.role === "client" ? all.filter((b) => b.clientId === req.user.id) : all;
    sendJSON(res, 200, { bookings: visible });
  });

  // ---------- PUT /api/bookings/:id (admin/staff approve, reject, move to in-progress) ----------
  router.put("/api/bookings/:id", authenticate, requireRole("admin", "staff"), (req, res) => {
    const { status } = req.body;
    const updated = db.collection("bookings").updateById(req.params.id, { status });
    if (!updated) return sendJSON(res, 404, { error: "Booking not found" });
    sendJSON(res, 200, { booking: updated });
  });

  // ---------- DELETE /api/bookings/:id ----------
  router.delete("/api/bookings/:id", authenticate, (req, res) => {
    const bookings = db.collection("bookings");
    const existing = bookings.findById(req.params.id);
    if (!existing) return sendJSON(res, 404, { error: "Booking not found" });
    if (req.user.role === "client" && existing.clientId !== req.user.id) {
      return sendJSON(res, 403, { error: "Forbidden" });
    }
    bookings.removeById(req.params.id);
    sendJSON(res, 200, { message: "Booking cancelled" });
  });
}

module.exports = { register };
