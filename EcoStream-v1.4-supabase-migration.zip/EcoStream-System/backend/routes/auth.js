const db = require("../lib/db");
const { hashPassword, verifyPassword, signToken, genId, genResetToken } = require("../lib/auth");
const { sendJSON, authenticate } = require("../lib/router");
const { requireFields, isEmail, ValidationError } = require("../lib/validate");
const { audit } = require("../lib/audit");
const { createSession, findValidSession, revokeSession, rotateSession } = require("../lib/sessions");

const MAX_LOGIN_ATTEMPTS = 5;
const LOCK_DURATION_MS = 15 * 60 * 1000; // 15 minutes

function publicUser(u) {
  const { password, resetToken, resetTokenExpires, emailVerificationToken, failedLoginAttempts, lockUntil, ...pub } = u;
  return pub;
}

function register(router) {
  // ---------- POST /api/auth/register (clients only self-register) ----------
  // Unchanged response shape (token, user) — refreshToken and
  // devEmailVerificationToken are additive fields, so existing frontend code
  // that only reads `token`/`user` keeps working exactly as before.
  router.post("/api/auth/register", (req, res) => {
    const { name, email, phone, address, password } = req.body;
    requireFields(req.body, ["name", "email", "phone", "password"]);
    if (!isEmail(email)) throw new ValidationError("Invalid email address");
    if (password.length < 8) throw new ValidationError("Password must be at least 8 characters");

    const users = db.collection("users");
    if (users.findOne((u) => u.email.toLowerCase() === email.toLowerCase())) {
      throw new ValidationError("An account with this email already exists");
    }

    const emailVerificationToken = genResetToken();
    const user = users.insert({
      id: genId("u"),
      role: "client",
      status: "active",
      name,
      email: email.toLowerCase(),
      phone,
      address: address || "",
      password: hashPassword(password),
      emailVerified: false,
      emailVerificationToken,
      failedLoginAttempts: 0,
      lockUntil: null,
      createdAt: new Date().toISOString(),
    });

    const token = signToken({ id: user.id, role: user.role, name: user.name });
    const refreshToken = createSession(req, user);
    audit({ user: { id: user.id, name: user.name, role: user.role } }, "register", { email: user.email });

    // No email service is wired up in this environment (see README) — the
    // verification token is returned directly so the flow is testable
    // end-to-end. In production this must be emailed, never returned here.
    sendJSON(res, 201, { token, refreshToken, user: publicUser(user), devEmailVerificationToken: emailVerificationToken });
  });

  // ---------- POST /api/auth/verify-email ----------
  router.post("/api/auth/verify-email", (req, res) => {
    const { token } = req.body;
    requireFields(req.body, ["token"]);
    const users = db.collection("users");
    const user = users.findOne((u) => u.emailVerificationToken === token);
    if (!user) return sendJSON(res, 400, { error: "Verification token is invalid or already used" });
    users.updateById(user.id, { emailVerified: true, emailVerificationToken: null });
    audit({ user: { id: user.id, name: user.name, role: user.role } }, "email_verified", {});
    sendJSON(res, 200, { message: "Email verified successfully." });
  });

  // ---------- POST /api/auth/login ----------
  router.post("/api/auth/login", (req, res) => {
    const { email, password } = req.body;
    requireFields(req.body, ["email", "password"]);

    const users = db.collection("users");
    const user = users.findOne((u) => u.email.toLowerCase() === String(email).toLowerCase());

    if (!user) {
      audit({ user: null }, "login_failed", { email });
      return sendJSON(res, 401, { error: "Invalid email or password" });
    }

    // ---------- account lockout ----------
    if (user.lockUntil && user.lockUntil > Date.now()) {
      const minutesLeft = Math.ceil((user.lockUntil - Date.now()) / 60000);
      audit({ user: { id: user.id, name: user.name, role: user.role } }, "login_blocked_locked", { minutesLeft });
      return sendJSON(res, 423, { error: `Account temporarily locked after too many failed attempts. Try again in ${minutesLeft} minute(s).` });
    }

    if (!verifyPassword(password, user.password)) {
      const attempts = (user.failedLoginAttempts || 0) + 1;
      const patch = { failedLoginAttempts: attempts };
      if (attempts >= MAX_LOGIN_ATTEMPTS) {
        patch.lockUntil = Date.now() + LOCK_DURATION_MS;
        audit({ user: { id: user.id, name: user.name, role: user.role } }, "account_locked", { attempts });
      }
      users.updateById(user.id, patch);
      audit({ user: null }, "login_failed", { email, attempts });
      return sendJSON(res, 401, { error: "Invalid email or password" });
    }

    if (user.status === "suspended") {
      audit({ user: { id: user.id, name: user.name, role: user.role } }, "login_blocked_suspended", {});
      return sendJSON(res, 403, { error: "This account has been suspended. Contact support." });
    }

    // successful login — reset lockout counters
    if (user.failedLoginAttempts || user.lockUntil) {
      users.updateById(user.id, { failedLoginAttempts: 0, lockUntil: null });
    }

    const token = signToken({ id: user.id, role: user.role, name: user.name });
    const refreshToken = createSession(req, user);
    audit({ user: { id: user.id, name: user.name, role: user.role } }, "login", { device: req.headers["user-agent"] });
    sendJSON(res, 200, { token, refreshToken, user: publicUser(user) });
  });

  // ---------- POST /api/auth/refresh ----------
  // Exchanges a valid, unexpired, unrevoked refresh token for a new access
  // token. The refresh token itself is rotated (old one revoked, new one
  // issued) on every use — standard practice so a leaked-then-reused old
  // refresh token is detectable/stale rather than silently still valid.
  router.post("/api/auth/refresh", (req, res) => {
    const { refreshToken } = req.body;
    requireFields(req.body, ["refreshToken"]);
    const session = findValidSession(refreshToken);
    if (!session) return sendJSON(res, 401, { error: "Refresh token is invalid, expired, or has been revoked" });

    const user = db.collection("users").findById(session.userId);
    if (!user) return sendJSON(res, 401, { error: "Account no longer exists" });
    if (user.status === "suspended") return sendJSON(res, 403, { error: "This account has been suspended." });

    const newRefreshToken = rotateSession(session, req);
    const token = signToken({ id: user.id, role: user.role, name: user.name });
    sendJSON(res, 200, { token, refreshToken: newRefreshToken });
  });

  // ---------- POST /api/auth/logout ----------
  // Revokes the session tied to the supplied refreshToken (if any) in
  // addition to the client discarding its access token — this is what makes
  // "sign out" actually revoke server-side state instead of just forgetting
  // a token that would otherwise keep working until it expires.
  router.post("/api/auth/logout", authenticate, (req, res) => {
    const { refreshToken } = req.body;
    if (refreshToken) {
      const session = findValidSession(refreshToken);
      if (session) revokeSession(session.id);
    }
    sendJSON(res, 200, { message: "Logged out" });
  });

  // ---------- POST /api/auth/forgot-password ----------
  router.post("/api/auth/forgot-password", (req, res) => {
    const { email } = req.body;
    requireFields(req.body, ["email"]);
    const users = db.collection("users");
    const user = users.findOne((u) => u.email.toLowerCase() === String(email).toLowerCase());
    // Always return 200 even if the user doesn't exist — do not leak which
    // emails are registered.
    if (!user) return sendJSON(res, 200, { message: "If that email exists, a reset link has been sent." });

    const resetToken = genResetToken();
    users.updateById(user.id, {
      resetToken,
      resetTokenExpires: Date.now() + 1000 * 60 * 30, // 30 min
    });

    // No email service is wired up in this environment — we return the token
    // directly so the flow is testable end-to-end. In production this must
    // be emailed, never returned in the API response.
    sendJSON(res, 200, {
      message: "If that email exists, a reset link has been sent.",
      devResetToken: resetToken,
    });
  });

  // ---------- POST /api/auth/reset-password ----------
  router.post("/api/auth/reset-password", (req, res) => {
    const { token, newPassword } = req.body;
    requireFields(req.body, ["token", "newPassword"]);
    if (newPassword.length < 8) throw new ValidationError("Password must be at least 8 characters");

    const users = db.collection("users");
    const user = users.findOne((u) => u.resetToken === token);
    if (!user || !user.resetTokenExpires || Date.now() > user.resetTokenExpires) {
      return sendJSON(res, 400, { error: "Reset token is invalid or has expired" });
    }
    users.updateById(user.id, {
      password: hashPassword(newPassword), resetToken: null, resetTokenExpires: null,
      failedLoginAttempts: 0, lockUntil: null, // a successful reset also clears any lockout
    });
    audit({ user: { id: user.id, name: user.name, role: user.role } }, "password_reset", {});
    sendJSON(res, 200, { message: "Password has been reset. You can now log in." });
  });

  // ---------- GET /api/auth/profile ----------
  router.get("/api/auth/profile", authenticate, (req, res) => {
    const user = db.collection("users").findById(req.user.id);
    if (!user) return sendJSON(res, 404, { error: "User not found" });
    sendJSON(res, 200, { user: publicUser(user) });
  });

  // ---------- PUT /api/auth/profile ----------
  router.put("/api/auth/profile", authenticate, (req, res) => {
    const { name, phone, address } = req.body;
    const patch = {};
    if (name) patch.name = name;
    if (phone) patch.phone = phone;
    if (address !== undefined) patch.address = address;
    const updated = db.collection("users").updateById(req.user.id, patch);
    if (!updated) return sendJSON(res, 404, { error: "User not found" });
    sendJSON(res, 200, { user: publicUser(updated) });
  });
}

module.exports = { register, publicUser };
