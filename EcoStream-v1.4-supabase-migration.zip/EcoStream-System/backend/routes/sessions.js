const db = require("../lib/db");
const { sendJSON, authenticate } = require("../lib/router");
const { revokeSession } = require("../lib/sessions");

function publicSession(s) {
  const { refreshTokenHash, ...pub } = s;
  return pub;
}

function register(router) {
  // ---------- GET /api/auth/sessions — list this user's active devices ----------
  router.get("/api/auth/sessions", authenticate, (req, res) => {
    const sessions = db
      .collection("sessions")
      .find((s) => s.userId === req.user.id && !s.revoked && s.expiresAt > Date.now())
      .sort((a, b) => b.lastUsedAt.localeCompare(a.lastUsedAt))
      .map(publicSession);
    sendJSON(res, 200, { sessions });
  });

  // ---------- DELETE /api/auth/sessions/:id — revoke one device ----------
  router.delete("/api/auth/sessions/:id", authenticate, (req, res) => {
    const session = db.collection("sessions").findById(req.params.id);
    if (!session || session.userId !== req.user.id) return sendJSON(res, 404, { error: "Session not found" });
    revokeSession(session.id);
    sendJSON(res, 200, { message: "Session revoked" });
  });

  // ---------- DELETE /api/auth/sessions — sign out of every device ----------
  router.delete("/api/auth/sessions", authenticate, (req, res) => {
    const sessions = db.collection("sessions").find((s) => s.userId === req.user.id && !s.revoked);
    sessions.forEach((s) => revokeSession(s.id));
    sendJSON(res, 200, { message: `Revoked ${sessions.length} session(s)` });
  });
}

module.exports = { register };
