const db = require("../lib/db");
const { genId } = require("../lib/auth");
const { sendJSON, authenticate, requireRole } = require("../lib/router");
const { requireFields, ValidationError } = require("../lib/validate");
const { getStorageProvider } = require("../lib/storage");

const MAX_BASE64_LEN = 8 * 1024 * 1024; // ~6MB decoded, generous for reports/PDFs/images

// Extension allowlist — deliberately conservative for a documents feature
// (reports, water-test results, contracts). Anything else is rejected rather
// than silently stored, since an upload endpoint is a common attack surface.
const SAFE_EXT = { "application/pdf": ".pdf", "image/png": ".png", "image/jpeg": ".jpg", "text/plain": ".txt",
  "application/msword": ".doc", "application/vnd.openxmlformats-officedocument.wordprocessingml.document": ".docx" };

function register(router) {
  // ---------- POST /api/documents (upload) ----------
  // Storage is provider-agnostic (see lib/storage) — this route just calls
  // save/read/remove and never touches fs directly, so switching
  // STORAGE_PROVIDER from local to s3/r2/supabase requires no route changes.
  router.post("/api/documents", authenticate, async (req, res) => {
    const { fileName, mimeType, base64Data, category, clientId } = req.body;
    requireFields(req.body, ["fileName", "mimeType", "base64Data"]);
    if (base64Data.length > MAX_BASE64_LEN) throw new ValidationError("File too large (max ~6MB)");
    if (!/^[A-Za-z0-9+/=]+$/.test(base64Data)) throw new ValidationError("base64Data is not valid base64");
    if (!SAFE_EXT[mimeType]) throw new ValidationError("Unsupported file type: " + mimeType);

    const ownerId = req.user.role === "client" ? req.user.id : clientId || null;
    const id = genId("doc");
    const storageKey = id + SAFE_EXT[mimeType];
    const storage = getStorageProvider();
    await storage.save(Buffer.from(base64Data, "base64"), storageKey, mimeType);

    const doc = db.collection("documents").insert({
      id,
      clientId: ownerId,
      fileName,
      mimeType,
      storageKey, // opaque key inside whichever provider is active — never a client-supplied path
      storageProvider: storage.name,
      category: category || "other", // report | water-test | contract | other
      uploadedBy: req.user.id,
      uploadedByRole: req.user.role,
      createdAt: new Date().toISOString(),
    });
    sendJSON(res, 201, { document: doc });
  });

  // ---------- GET /api/documents (list — metadata only) ----------
  router.get("/api/documents", authenticate, (req, res) => {
    const all = db.collection("documents").all();
    const visible = req.user.role === "client" ? all.filter((d) => d.clientId === req.user.id) : all;
    sendJSON(res, 200, { documents: visible });
  });

  // ---------- GET /api/documents/:id (download) ----------
  router.get("/api/documents/:id", authenticate, async (req, res) => {
    const doc = db.collection("documents").findById(req.params.id);
    if (!doc) return sendJSON(res, 404, { error: "Document not found" });
    if (req.user.role === "client" && doc.clientId !== req.user.id) {
      return sendJSON(res, 403, { error: "Forbidden" });
    }
    const storage = getStorageProvider();
    const buffer = await storage.read(doc.storageKey);
    if (!buffer) return sendJSON(res, 404, { error: "File missing from storage" });
    sendJSON(res, 200, { document: { ...doc, base64Data: buffer.toString("base64") } });
  });

  // ---------- DELETE /api/documents/:id ----------
  router.delete("/api/documents/:id", authenticate, requireRole("admin", "staff"), async (req, res) => {
    const doc = db.collection("documents").findById(req.params.id);
    if (!doc) return sendJSON(res, 404, { error: "Document not found" });
    const storage = getStorageProvider();
    await storage.remove(doc.storageKey);
    db.collection("documents").removeById(req.params.id);
    sendJSON(res, 200, { message: "Document deleted" });
  });
}

module.exports = { register };
