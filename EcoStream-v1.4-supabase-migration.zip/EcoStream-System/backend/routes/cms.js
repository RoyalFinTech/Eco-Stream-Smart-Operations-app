const db = require("../lib/db");
const { sendJSON, authenticate, requireRole } = require("../lib/router");
const { audit } = require("../lib/audit");

const DEFAULT_CMS = {
  heroTitle: "No Water At Home? Drill Your Own Borehole Today!",
  heroSubtitle: "Fast · Reliable · Affordable borehole drilling across The Gambia",
  contactPhone: "+220 380 6666",
  contactAddress: "Banjul, The Gambia",
  contactHours: "Mon–Sat, 8am–6pm",
};

function register(router) {
  // ---------- GET /api/cms (public — the client portal reads this on load) ----------
  router.get("/api/cms", (req, res) => {
    const rows = db.collection("cms").all();
    const content = rows.length ? rows[0] : DEFAULT_CMS;
    sendJSON(res, 200, { content });
  });

  // ---------- PUT /api/cms (admin only) ----------
  router.put("/api/cms", authenticate, requireRole("admin"), (req, res) => {
    const cms = db.collection("cms");
    const rows = cms.all();
    let updated;
    if (rows.length) {
      updated = cms.updateById(rows[0].id, req.body);
    } else {
      updated = cms.insert({ id: "cms_1", ...DEFAULT_CMS, ...req.body });
    }
    audit(req, "cms_updated", { fields: Object.keys(req.body) });
    sendJSON(res, 200, { content: updated });
  });

  // ---------- GET /api/audit-logs (admin only) ----------
  router.get("/api/audit-logs", authenticate, requireRole("admin"), (req, res) => {
    const logs = db.collection("auditLogs").all().sort((a, b) => b.date.localeCompare(a.date)).slice(0, 500);
    sendJSON(res, 200, { logs });
  });
}

module.exports = { register };
