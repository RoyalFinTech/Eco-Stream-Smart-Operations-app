const db = require("../lib/db");
const { genId } = require("../lib/auth");
const { sendJSON, authenticate, requireRole } = require("../lib/router");
const { requireFields } = require("../lib/validate");
const { paginate, textFilter } = require("../lib/pagination");

function nextTicketNumber() {
  const count = db.collection("tickets").all().length + 1;
  return "TCK-" + String(count).padStart(4, "0");
}

function register(router) {
  // ---------- POST /api/tickets ----------
  router.post("/api/tickets", authenticate, (req, res) => {
    const { subject, description, category, priority, location } = req.body;
    requireFields(req.body, ["subject", "description"]);
    const ticket = db.collection("tickets").insert({
      id: genId("t"),
      ticketNumber: nextTicketNumber(),
      clientId: req.user.role === "client" ? req.user.id : req.body.clientId || null,
      subject,
      description,
      category: category || "general",
      priority: priority || "medium",
      status: "open",
      location: location || "",
      replies: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });
    sendJSON(res, 201, { ticket });
  });

  // ---------- GET /api/tickets ----------
  // Backward compatible: no query params -> { tickets: [...] } as before.
  // ?search=, ?status=, ?page=/?pageSize= opt into filtering/paging.
  router.get("/api/tickets", authenticate, (req, res) => {
    const all = db.collection("tickets").all();
    let visible = req.user.role === "client" ? all.filter((t) => t.clientId === req.user.id) : all;
    if (req.query.status) visible = visible.filter((t) => t.status === req.query.status);
    visible = textFilter(visible, req.query.search, ["subject", "description", "ticketNumber", "location"]);
    const { items, paginated, meta } = paginate(visible, req.query);
    sendJSON(res, 200, paginated ? { tickets: items, meta } : { tickets: items });
  });

  // ---------- PUT /api/tickets/:id (status change and/or reply) ----------
  router.put("/api/tickets/:id", authenticate, (req, res) => {
    const tickets = db.collection("tickets");
    const existing = tickets.findById(req.params.id);
    if (!existing) return sendJSON(res, 404, { error: "Ticket not found" });
    if (req.user.role === "client" && existing.clientId !== req.user.id) {
      return sendJSON(res, 403, { error: "Forbidden" });
    }
    const patch = {};
    if (req.body.status && (req.user.role === "admin" || req.user.role === "staff")) patch.status = req.body.status;
    if (req.body.reply) {
      patch.replies = [
        ...(existing.replies || []),
        { id: genId("rp"), author: req.user.name, message: req.body.reply, date: new Date().toISOString() },
      ];
    }
    const updated = tickets.updateById(req.params.id, patch);
    sendJSON(res, 200, { ticket: updated });
  });

  // ---------- DELETE /api/tickets/:id ----------
  router.delete("/api/tickets/:id", authenticate, requireRole("admin", "staff"), (req, res) => {
    const ok = db.collection("tickets").removeById(req.params.id);
    if (!ok) return sendJSON(res, 404, { error: "Ticket not found" });
    sendJSON(res, 200, { message: "Ticket deleted" });
  });
}

module.exports = { register };
