// repositories/createRepository.js
//
// ⚠️ STATUS: written, not runnable without a live Postgres connection (see
// prismaClient.js). This factory gives every Prisma model the same shape as
// lib/db.js's collection() API — all/find/findOne/findById/insert/
// updateById/removeById — so migrating a route from JSON to Postgres means
// changing `db.collection("users")` to `repository("user")` and adding
// `await`, not rewriting query logic from scratch. See
// documentation/POSTGRES_MIGRATION.md for a fully worked example
// (routes/clients.postgres.js).

const { getPrismaClient } = require("./prismaClient");

function createRepository(modelName) {
  const prisma = () => getPrismaClient()[modelName];

  return {
    async all() {
      return prisma().findMany();
    },
    // `predicateOrWhere` accepts either a Prisma `where` object (preferred —
    // translates to a real SQL WHERE clause) or a JS predicate function (for
    // parity with lib/db.js call sites during migration; less efficient
    // since it fetches all rows first, so replace with a `where` object once
    // a route is fully converted).
    async find(predicateOrWhere) {
      if (typeof predicateOrWhere === "function") {
        const rows = await prisma().findMany();
        return rows.filter(predicateOrWhere);
      }
      return prisma().findMany({ where: predicateOrWhere });
    },
    async findOne(predicateOrWhere) {
      if (typeof predicateOrWhere === "function") {
        const rows = await prisma().findMany();
        return rows.find(predicateOrWhere) || null;
      }
      return prisma().findFirst({ where: predicateOrWhere });
    },
    async findById(id) {
      return prisma().findUnique({ where: { id } });
    },
    async insert(data) {
      return prisma().create({ data });
    },
    async updateById(id, patch) {
      try {
        return await prisma().update({ where: { id }, data: patch });
      } catch {
        return null; // matches lib/db.js behavior: updating a missing id returns null, not a throw
      }
    },
    async removeById(id) {
      try {
        await prisma().delete({ where: { id } });
        return true;
      } catch {
        return false;
      }
    },
  };
}

module.exports = { createRepository };
