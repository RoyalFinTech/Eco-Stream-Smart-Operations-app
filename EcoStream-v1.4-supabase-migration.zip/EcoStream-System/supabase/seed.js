// supabase/seed.js
//
// ⚠️ STATUS: written against the real, installed @supabase/supabase-js
// library (v2.110.8 — confirmed by introspecting the actual installed
// package's methods and TypeScript definitions, not written from memory).
// The API calls below are structurally correct. This script has NOT been
// run against a real Supabase project — there is none reachable from this
// environment. Run it yourself once you have a project: see
// documentation-supabase/SUPABASE_SETUP.md.
//
// Why a .js script and not a seed.sql insert into auth.users: Supabase's own
// docs advise against inserting into auth.users directly (it's an
// internally-managed table with additional bookkeeping rows in other auth.*
// tables that a plain INSERT won't populate). The documented, supported way
// to create users programmatically is the Admin API's createUser() method,
// which is what this script uses — the same call your own future seed/import
// tooling should use.
//
// Requires: SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY environment variables
// (service role key — never expose this to a frontend/browser context).
// Run with: node supabase/seed.js

const { createClient } = require("@supabase/supabase-js");

const SUPABASE_URL = process.env.SUPABASE_URL;
const SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!SUPABASE_URL || !SERVICE_ROLE_KEY) {
  console.error("Set SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY before running this script.");
  process.exit(1);
}

const supabase = createClient(SUPABASE_URL, SERVICE_ROLE_KEY, {
  auth: { autoRefreshToken: false, persistSession: false },
});

// Mirrors backend/lib/seed.js's demo accounts exactly, so behavior during
// manual testing matches what's documented elsewhere in this repo.
const DEMO_USERS = [
  { email: "admin@ecostream.gm", password: "Admin@1234", name: "Ebrima Colley", phone: "+220 3000001", role: "admin", staff_role: "administrator" },
  { email: "engineer@ecostream.gm", password: "Engineer@1234", name: "Momodou Jarju", phone: "+220 3000002", role: "staff", staff_role: "engineer" },
  { email: "lamin@example.com", password: "Client@1234", name: "Lamin Jallow", phone: "+220 7111111", role: "client", address: "Bakau, The Gambia" },
  { email: "fatou@example.com", password: "Client@1234", name: "Fatou Ceesay", phone: "+220 7222222", role: "client", address: "Serrekunda, The Gambia" },
];

async function seedUsers() {
  const created = {};
  for (const u of DEMO_USERS) {
    // The on_auth_user_created trigger (0001_init_schema.sql) reads
    // raw_user_meta_data to populate the profiles table automatically —
    // that's why name/phone/role are passed as user_metadata here rather
    // than inserted into `profiles` separately afterward.
    const { data, error } = await supabase.auth.admin.createUser({
      email: u.email,
      password: u.password,
      email_confirm: true, // demo accounts — skip the real email verification flow
      user_metadata: { name: u.name, phone: u.phone, role: u.role },
    });
    if (error) {
      console.error(`Failed to create ${u.email}:`, error.message);
      continue;
    }
    created[u.email] = data.user.id;
    console.log(`Created ${u.email} -> ${data.user.id}`);

    // staff_role and address aren't set by the trigger (it only knows
    // name/phone/role) — patch them in as a follow-up update.
    if (u.staff_role || u.address) {
      await supabase.from("profiles").update({
        ...(u.staff_role ? { staff_role: u.staff_role } : {}),
        ...(u.address ? { address: u.address } : {}),
      }).eq("id", data.user.id);
    }
  }
  return created;
}

async function seedSampleData(userIds) {
  const laminId = userIds["lamin@example.com"];
  const fatouId = userIds["fatou@example.com"];
  const engineerId = userIds["engineer@ecostream.gm"];
  if (!laminId || !fatouId) {
    console.log("Skipping sample data — demo client accounts weren't created (see errors above).");
    return;
  }

  await supabase.from("projects").insert([
    { client_id: laminId, location: "Bakau, The Gambia", status: "ongoing", depth: 42, total_depth: 60,
      soil_type: "Laterite", assigned_engineer_id: engineerId, notes: "Drilling proceeding on schedule.",
      start_date: "2026-06-20" },
    { client_id: fatouId, location: "Serrekunda, The Gambia", status: "completed", depth: 55, total_depth: 55,
      water_yield: 3.2, soil_type: "Sandy clay", assigned_engineer_id: engineerId,
      notes: "Completed and commissioned. Solar pump installed.", start_date: "2026-05-02" },
  ]);

  await supabase.from("bookings").insert([
    { client_id: laminId, package: "solar", drilling_location: "Bakau, The Gambia", payment_plan: "installment", status: "approved" },
  ]);

  console.log("Sample projects and bookings seeded.");
}

(async () => {
  console.log(`Seeding ${SUPABASE_URL} ...`);
  const userIds = await seedUsers();
  await seedSampleData(userIds);
  console.log("Done.");
})();
