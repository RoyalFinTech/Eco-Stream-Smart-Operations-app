// supabase/functions/upload-document/index.ts
//
// ⚠️ STATUS: same verification caveat as approve-booking/index.ts — written
// against the real supabase-js v2 API, locally type-checked with tsc against
// a Deno stub, never deployed or invoked against a real project.
//
// Mirrors backend/routes/documents.js: validates mime type and size before
// storing, then records metadata in the `documents` table. The actual file
// bytes go to Supabase Storage's `documents` bucket (see
// supabase/migrations/0003_storage_buckets.sql) at a path prefixed with the
// uploader's own user id, which is what the storage RLS policies check.
//
// deno-lint-ignore-file no-explicit-any
/// <reference path="../_shared/_deno_types_for_local_check_only.d.ts" />
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { corsHeaders } from "../_shared/cors.ts";

const MAX_BYTES = 6 * 1024 * 1024; // matches backend/routes/documents.js's ~6MB limit
const SAFE_EXT: Record<string, string> = {
  "application/pdf": ".pdf",
  "image/png": ".png",
  "image/jpeg": ".jpg",
  "text/plain": ".txt",
  "application/msword": ".doc",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document": ".docx",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization") ?? "";
    const jwt = authHeader.replace("Bearer ", "");

    const userClient = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );
    const { data: userData, error: userError } = await userClient.auth.getUser(jwt);
    if (userError || !userData.user) {
      return new Response(JSON.stringify({ error: "Invalid or expired token" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { fileName, mimeType, base64Data, category, clientId } = await req.json();
    if (!fileName || !mimeType || !base64Data) {
      return new Response(JSON.stringify({ error: "fileName, mimeType, and base64Data are required" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (!SAFE_EXT[mimeType]) {
      return new Response(JSON.stringify({ error: `Unsupported file type: ${mimeType}` }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const bytes = Uint8Array.from(atob(base64Data), (c) => c.charCodeAt(0));
    if (bytes.byteLength > MAX_BYTES) {
      return new Response(JSON.stringify({ error: "File too large (max ~6MB)" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const adminClient = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    // Staff/admin can upload on behalf of a client (clientId in the body);
    // a client can only ever upload as themselves — mirrors the ownership
    // rule in the original documents.js route.
    const { data: profile } = await adminClient
      .from("profiles").select("role").eq("id", userData.user.id).single();
    const isStaffOrAdmin = profile && (profile.role === "staff" || profile.role === "admin");
    const ownerId = isStaffOrAdmin && clientId ? clientId : userData.user.id;

    const docId = crypto.randomUUID();
    const storagePath = `${ownerId}/${docId}${SAFE_EXT[mimeType]}`;

    const { error: uploadError } = await adminClient.storage
      .from("documents")
      .upload(storagePath, bytes, { contentType: mimeType });
    if (uploadError) throw uploadError;

    const { data: doc, error: dbError } = await adminClient
      .from("documents")
      .insert({
        id: docId,
        client_id: ownerId,
        file_name: fileName,
        mime_type: mimeType,
        storage_path: storagePath,
        category: category ?? "other",
        uploaded_by: userData.user.id,
      })
      .select()
      .single();
    if (dbError) throw dbError;

    return new Response(JSON.stringify({ document: doc }), {
      status: 201, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: (err as any)?.message ?? "Internal error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
