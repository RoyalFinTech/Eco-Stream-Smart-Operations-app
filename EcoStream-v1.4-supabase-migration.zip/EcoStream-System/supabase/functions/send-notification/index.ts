// supabase/functions/send-notification/index.ts
//
// ⚠️ STATUS: same verification caveat as the other two functions in this
// directory — written against the real supabase-js v2 API, locally type-
// checked with tsc, never deployed or invoked against a real project.
//
// Mirrors backend/routes/notifications.js's POST /api/notifications
// (staff/admin only, userId omitted = broadcast to everyone).
//
// deno-lint-ignore-file no-explicit-any
/// <reference path="../_shared/_deno_types_for_local_check_only.d.ts" />
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { corsHeaders } from "../_shared/cors.ts";

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization") ?? "";
    const jwt = authHeader.replace("Bearer ", "");

    const userClient = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );
    const { data: userData, error: userError } = await userClient.auth.getUser(jwt);
    if (userError || !userData.user) {
      return new Response(JSON.stringify({ error: "Invalid or expired token" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const adminClient = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );
    const { data: profile } = await adminClient
      .from("profiles").select("role").eq("id", userData.user.id).single();
    if (!profile || (profile.role !== "staff" && profile.role !== "admin")) {
      return new Response(JSON.stringify({ error: "Forbidden — staff or admin only" }), {
        status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { userId, type, title, message } = await req.json();
    if (!title || !message) {
      return new Response(JSON.stringify({ error: "title and message are required" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: notification, error } = await adminClient
      .from("notifications")
      .insert({ user_id: userId ?? null, type: type ?? "system", title, message })
      .select()
      .single();
    if (error) throw error;

    // Realtime note (see documentation-supabase/EDGE_FUNCTIONS.md and the
    // Realtime section of DEPLOYMENT.md): if Realtime is enabled on the
    // `notifications` table, this insert is all that's needed for
    // subscribed clients to receive it instantly — no separate "push" step,
    // unlike the original app's 4-second polling loop.

    return new Response(JSON.stringify({ notification }), {
      status: 201, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: (err as any)?.message ?? "Internal error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
