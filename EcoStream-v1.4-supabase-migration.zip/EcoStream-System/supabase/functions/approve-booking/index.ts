// supabase/functions/approve-booking/index.ts
//
// ⚠️ STATUS: written against the real @supabase/supabase-js v2 API (verified
// by introspecting the installed package — see documentation-supabase/
// EDGE_FUNCTIONS.md for exactly what was and wasn't checked), syntax/type
// checked locally with `tsc` against a minimal Deno stub (see
// _shared/_deno_types_for_local_check_only.d.ts). NOT deployed or invoked
// against a real Supabase project — there is none reachable from this
// environment. Deploy with `supabase functions deploy approve-booking`
// once you have a real project.
//
// Mirrors the existing admin-portal workflow: PUT /api/bookings/:id
// {status:"approved"} followed by POST /api/projects — combined into one
// server-side operation here so both writes either both succeed or the
// caller gets a clear error, rather than the frontend doing two separate
// requests that could partially fail.
//
// deno-lint-ignore-file no-explicit-any
/// <reference path="../_shared/_deno_types_for_local_check_only.d.ts" />
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { corsHeaders } from "../_shared/cors.ts";

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization") ?? "";
    const jwt = authHeader.replace("Bearer ", "");
    if (!jwt) {
      return new Response(JSON.stringify({ error: "Missing Authorization header" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Two clients, deliberate distinction:
    //  - `userClient` authenticates as the caller (RLS applies) to verify
    //    who they are and that they're staff/admin.
    //  - `adminClient` uses the service role to perform the privileged
    //    multi-table write, bypassing RLS intentionally — the authorization
    //    check above is what makes this safe, not RLS on these two tables.
    const userClient = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );
    const adminClient = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const { data: userData, error: userError } = await userClient.auth.getUser(jwt);
    if (userError || !userData.user) {
      return new Response(JSON.stringify({ error: "Invalid or expired token" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: profile } = await adminClient
      .from("profiles").select("role").eq("id", userData.user.id).single();
    if (!profile || (profile.role !== "staff" && profile.role !== "admin")) {
      return new Response(JSON.stringify({ error: "Forbidden — staff or admin only" }), {
        status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { bookingId, totalDepth } = await req.json();
    if (!bookingId) {
      return new Response(JSON.stringify({ error: "bookingId is required" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: booking, error: fetchError } = await adminClient
      .from("bookings").select("*").eq("id", bookingId).single();
    if (fetchError || !booking) {
      return new Response(JSON.stringify({ error: "Booking not found" }), {
        status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { error: updateError } = await adminClient
      .from("bookings").update({ status: "approved" }).eq("id", bookingId);
    if (updateError) throw updateError;

    const { data: project, error: projectError } = await adminClient
      .from("projects")
      .insert({
        client_id: booking.client_id,
        location: booking.drilling_location,
        total_depth: totalDepth ?? 60,
      })
      .select()
      .single();
    if (projectError) throw projectError;

    await adminClient.from("audit_logs").insert({
      actor_id: userData.user.id,
      actor_name: userData.user.email,
      actor_role: profile.role,
      action: "booking_approved_project_created",
      details: { bookingId, projectId: project.id },
    });

    return new Response(JSON.stringify({ booking: { ...booking, status: "approved" }, project }), {
      status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: (err as any)?.message ?? "Internal error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
