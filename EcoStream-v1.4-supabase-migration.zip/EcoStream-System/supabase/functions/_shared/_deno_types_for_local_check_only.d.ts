// _deno_types_for_local_check_only.d.ts
//
// This file exists ONLY so `tsc` can syntax/type-check the Edge Functions in
// this repository from within a plain Node/TypeScript environment — Deno's
// real global types are far more complete than this stub. It is NOT part of
// the deployed function and should not be uploaded to Supabase; the real
// Deno runtime provides its own, correct global types when you actually
// deploy with `supabase functions deploy`.
declare const Deno: {
  serve: (handler: (req: Request) => Response | Promise<Response>) => void;
  env: { get: (key: string) => string | undefined };
};
