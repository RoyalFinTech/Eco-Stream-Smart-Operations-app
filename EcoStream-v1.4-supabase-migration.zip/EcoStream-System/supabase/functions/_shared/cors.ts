// supabase/functions/_shared/cors.ts
//
// ⚠️ STATUS: written, not deployed/run — see documentation-supabase/EDGE_FUNCTIONS.md.
export const corsHeaders = {
  "Access-Control-Allow-Origin": "*", // tighten to your real portal origins before production — see documentation-supabase/EDGE_FUNCTIONS.md
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};
