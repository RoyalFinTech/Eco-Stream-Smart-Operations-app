// supabase/frontend-integration/supabase-client.example.js
//
// ⚠️ STATUS: reference implementation, NOT wired into client-portal/index.html
// or admin-portal/index.html. Those two files are the tested, working,
// verified frontend (see documentation/PRODUCTION_READINESS_REPORT.md) —
// per "preserve existing UI" and "do not introduce breaking changes," this
// migration does not rip that out. This file shows the pattern you'd follow
// to replace the existing `api()` fetch-wrapper calls in both portals with
// direct Supabase calls, one function at a time, verifying each in a real
// browser against a real project as you go.
//
// Verification performed on this file: the method names and call shapes
// below (auth.signInWithPassword, auth.signUp, .from().select/insert/update,
// storage.from().upload, .channel().on().subscribe()) were checked against
// the real, installed @supabase/supabase-js v2.110.8 package's own
// TypeScript definitions — not written from memory. What was NOT verified:
// actually calling any of this against a live Supabase project (none
// reachable here), and loading @supabase/supabase-js from a CDN in a real
// browser (this sandbox's browser tool is blocked from every CDN host tried
// — esm.sh, jsdelivr, unpkg — even though Node's own npm registry access
// works; see documentation-supabase/SUPABASE_SETUP.md for that finding).
//
// In a real deployment, load the library in each portal's <head> with:
//   <script type="module">
//     import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
//     window.supabase = createClient('<SUPABASE_URL>', '<SUPABASE_ANON_KEY>')
//   </script>
// then replace calls to this project's local api() helper with the
// equivalents below.

// ---------- auth (replaces POST /api/auth/register, /login, /refresh, /logout) ----------
async function registerClient({ email, password, name, phone, address }) {
  // The on_auth_user_created trigger (supabase/migrations/0001_init_schema.sql)
  // reads user_metadata to populate the profiles table automatically.
  const { data, error } = await supabase.auth.signUp({
    email, password,
    options: { data: { name, phone, address, role: "client" } },
  });
  return { data, error };
}

async function login({ email, password }) {
  // Supabase Auth manages the access + refresh token pair, storage, and
  // rotation itself — this replaces the custom lib/sessions.js /
  // POST /api/auth/refresh entirely. supabase-js persists the session in
  // localStorage and refreshes it automatically; no equivalent of the old
  // trySilentRefresh() wrapper is needed in application code.
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  return { data, error };
}

async function logout() {
  // Ends the current session server-side (revokes the refresh token) —
  // replaces POST /api/auth/logout.
  return supabase.auth.signOut();
}

// ---------- data (replaces GET/POST /api/projects, /api/tickets, etc.) ----------
async function getMyProjects() {
  // RLS (supabase/migrations/0002_rls_policies.sql) does the ownership
  // filtering server-side — no need to pass a clientId or trust a client-
  // supplied filter; a client's query only ever returns their own rows,
  // and staff/admin's returns everyone's, enforced by Postgres itself.
  const { data, error } = await supabase.from("projects").select("*");
  return { data, error };
}

async function createTicket({ subject, description, category, priority, location }) {
  const { data: userData } = await supabase.auth.getUser();
  const { data, error } = await supabase
    .from("tickets")
    .insert({
      client_id: userData.user.id,
      subject, description,
      category: category ?? "general",
      priority: priority ?? "medium",
      location,
    })
    .select()
    .single();
  return { data, error };
}

// ---------- storage (replaces POST/GET /api/documents) ----------
async function uploadDocument({ file, category }) {
  const { data: userData } = await supabase.auth.getUser();
  const path = `${userData.user.id}/${crypto.randomUUID()}-${file.name}`;
  const { data: uploadData, error: uploadError } = await supabase.storage
    .from("documents")
    .upload(path, file, { contentType: file.type });
  if (uploadError) return { error: uploadError };

  const { data, error } = await supabase
    .from("documents")
    .insert({
      client_id: userData.user.id,
      file_name: file.name,
      mime_type: file.type,
      storage_path: uploadData.path,
      category: category ?? "other",
      uploaded_by: userData.user.id,
    })
    .select()
    .single();
  return { data, error };
}

async function downloadDocument(storagePath) {
  // Signed URL — time-limited, doesn't require the bucket to be public.
  // Replaces GET /api/documents/:id's base64-in-JSON response.
  const { data, error } = await supabase.storage
    .from("documents")
    .createSignedUrl(storagePath, 60); // 60 seconds
  return { data, error };
}

// ---------- realtime (replaces the client portal's 4-second chat/notification poll) ----------
function subscribeToMyNotifications(userId, onNotification) {
  // Direct replacement for client-portal/index.html's setInterval polling
  // in loadNotifications()/refreshChat() — see documentation-supabase/
  // DEPLOYMENT.md's Realtime section for the trade-offs (a persistent
  // WebSocket connection per open tab vs. a periodic HTTP request).
  return supabase
    .channel(`notifications:${userId}`)
    .on(
      "postgres_changes",
      { event: "INSERT", schema: "public", table: "notifications", filter: `user_id=eq.${userId}` },
      (payload) => onNotification(payload.new)
    )
    .subscribe();
}

module.exports = {
  registerClient, login, logout, getMyProjects, createTicket,
  uploadDocument, downloadDocument, subscribeToMyNotifications,
};
