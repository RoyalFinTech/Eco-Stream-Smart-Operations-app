-- supabase/migrations/0001_init_schema.sql
--
-- ⚠️ STATUS: written and internally reviewed, but NOT executed against a real
-- Supabase project. This environment has no Supabase account/credentials and
-- no Docker (so `supabase start`'s local stack can't run either) — see
-- documentation-supabase/SUPABASE_SETUP.md for exactly what to do with this
-- file once you have a real project. Treat this as a correct starting point
-- to run through `supabase db push` (or the SQL editor) against a project
-- you control, not as something already proven to work.
--
-- Architectural note vs. the earlier Prisma schema (backend/prisma/schema.prisma):
-- Supabase Auth owns the user/session/password/email-verification/refresh-token
-- concerns natively (auth.users, auth.sessions — both managed by Supabase, not
-- created here). This migration only adds a `profiles` table (1:1 with
-- auth.users) for the app-specific fields (role, phone, address, status) that
-- Supabase Auth doesn't know about. Every other table's foreign keys now
-- point at profiles.id (== auth.users.id) instead of a custom users table.
-- The custom `sessions` table from the Prisma design is gone entirely —
-- Supabase Auth's own session/refresh-token handling replaces it.

-- ============================================================
-- ENUMS
-- ============================================================
create type public.user_role as enum ('client', 'staff', 'admin');
create type public.client_status as enum ('active', 'suspended', 'pending');
create type public.project_status as enum ('pending', 'ongoing', 'completed');
create type public.booking_status as enum ('pending', 'approved', 'rejected');
create type public.payment_status as enum ('paid', 'pending');
create type public.ticket_status as enum ('open', 'in-progress', 'resolved');
create type public.document_category as enum ('report', 'water-test', 'contract', 'other');
create type public.chat_sender as enum ('client', 'company');

-- ============================================================
-- PROFILES — 1:1 extension of auth.users for app-specific fields
-- ============================================================
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role public.user_role not null default 'client',
  staff_role text, -- engineer | technician | driver | administrator (only meaningful when role='staff'/'admin')
  name text not null,
  phone text not null,
  address text,
  status public.client_status not null default 'active',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index profiles_role_idx on public.profiles(role);

-- Auto-create a profile row whenever a new auth.users row is created —
-- keeps profiles in lockstep with Supabase Auth's own user table without the
-- application having to remember to do it in two places.
create function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, name, phone, role)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'name', 'Unnamed'),
    coalesce(new.raw_user_meta_data->>'phone', ''),
    coalesce((new.raw_user_meta_data->>'role')::public.user_role, 'client')
  );
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ============================================================
-- PROJECTS
-- ============================================================
create table public.projects (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.profiles(id),
  location text not null,
  status public.project_status not null default 'pending',
  depth integer not null default 0,
  total_depth integer not null default 60,
  water_yield numeric not null default 0,
  soil_type text,
  start_date timestamptz not null default now(),
  assigned_engineer_id uuid references public.profiles(id),
  notes text,
  timeline jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index projects_client_id_idx on public.projects(client_id);
create index projects_status_idx on public.projects(status);

-- ============================================================
-- BOOKINGS
-- ============================================================
create table public.bookings (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.profiles(id),
  request_type text not null default 'drilling',
  package text not null default 'standard',
  drilling_location text not null,
  area_type text not null default 'residential',
  purpose text not null default 'drinking',
  payment_plan text not null default 'full',
  status public.booking_status not null default 'pending',
  submitted_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);
create index bookings_client_id_idx on public.bookings(client_id);
create index bookings_status_idx on public.bookings(status);

-- ============================================================
-- PAYMENTS
-- ============================================================
create table public.payments (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.profiles(id),
  project_id uuid references public.projects(id),
  amount numeric(12,2) not null check (amount > 0),
  method text not null,
  status public.payment_status not null default 'paid',
  date timestamptz not null default now(),
  created_at timestamptz not null default now()
);
create index payments_client_id_idx on public.payments(client_id);
create index payments_status_idx on public.payments(status);

-- ============================================================
-- NOTIFICATIONS
-- ============================================================
create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id), -- null = system-wide broadcast
  type text not null default 'system',
  title text not null,
  message text not null,
  read boolean not null default false,
  date timestamptz not null default now(),
  created_at timestamptz not null default now()
);
create index notifications_user_id_idx on public.notifications(user_id);

-- ============================================================
-- TICKETS
-- ============================================================
create table public.tickets (
  id uuid primary key default gen_random_uuid(),
  ticket_number text not null unique,
  client_id uuid references public.profiles(id),
  subject text not null,
  description text not null,
  category text not null default 'general',
  priority text not null default 'medium',
  status public.ticket_status not null default 'open',
  location text,
  replies jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index tickets_client_id_idx on public.tickets(client_id);
create index tickets_status_idx on public.tickets(status);

-- Auto-generate ticket numbers (TCK-0001, TCK-0002, ...) instead of the
-- application counting existing rows — safer under concurrent inserts,
-- which the original JSON-file implementation could not guarantee.
create sequence public.ticket_number_seq start 1;
create function public.set_ticket_number()
returns trigger language plpgsql as $$
begin
  if new.ticket_number is null then
    new.ticket_number := 'TCK-' || lpad(nextval('public.ticket_number_seq')::text, 4, '0');
  end if;
  return new;
end;
$$;
create trigger tickets_set_number before insert on public.tickets
  for each row execute procedure public.set_ticket_number();

-- ============================================================
-- DOCUMENTS (metadata only — bytes live in Supabase Storage, see
-- 0002_storage_buckets.sql and documentation-supabase/STORAGE.md)
-- ============================================================
create table public.documents (
  id uuid primary key default gen_random_uuid(),
  client_id uuid references public.profiles(id),
  file_name text not null,
  mime_type text not null,
  storage_path text not null, -- path within the 'documents' bucket
  category public.document_category not null default 'other',
  uploaded_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now()
);
create index documents_client_id_idx on public.documents(client_id);

-- ============================================================
-- CHAT MESSAGES
-- ============================================================
create table public.chat_messages (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.profiles(id),
  sender public.chat_sender not null,
  sender_name text not null,
  message text not null,
  read boolean not null default false,
  created_at timestamptz not null default now()
);
create index chat_messages_client_id_idx on public.chat_messages(client_id);

-- ============================================================
-- EQUIPMENT & EXPENSES (staff/admin only — no client-facing rows)
-- ============================================================
create table public.equipment (
  id uuid primary key default gen_random_uuid(),
  type text not null,
  name text not null,
  status text not null default 'active',
  last_maintenance timestamptz,
  created_at timestamptz not null default now()
);

create table public.expenses (
  id uuid primary key default gen_random_uuid(),
  category text not null,
  amount numeric(12,2) not null check (amount > 0),
  note text,
  date timestamptz not null default now(),
  created_at timestamptz not null default now()
);

-- ============================================================
-- CMS (single row of site content)
-- ============================================================
create table public.cms (
  id text primary key default 'cms_1',
  hero_title text not null default 'No Water At Home? Drill Your Own Borehole Today!',
  hero_subtitle text not null default 'Fast · Reliable · Affordable borehole drilling across The Gambia',
  contact_phone text not null default '+220 380 6666',
  contact_address text not null default 'Banjul, The Gambia',
  contact_hours text not null default 'Mon–Sat, 8am–6pm'
);
insert into public.cms (id) values ('cms_1');

-- ============================================================
-- AUDIT LOGS
-- ============================================================
create table public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references public.profiles(id),
  actor_name text not null,
  actor_role text,
  action text not null,
  details jsonb not null default '{}'::jsonb,
  ip text,
  date timestamptz not null default now()
);
create index audit_logs_actor_id_idx on public.audit_logs(actor_id);
create index audit_logs_date_idx on public.audit_logs(date);

-- ============================================================
-- updated_at auto-touch trigger, shared by every table that has the column
-- ============================================================
create function public.touch_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger profiles_touch before update on public.profiles for each row execute procedure public.touch_updated_at();
create trigger projects_touch before update on public.projects for each row execute procedure public.touch_updated_at();
create trigger tickets_touch before update on public.tickets for each row execute procedure public.touch_updated_at();
