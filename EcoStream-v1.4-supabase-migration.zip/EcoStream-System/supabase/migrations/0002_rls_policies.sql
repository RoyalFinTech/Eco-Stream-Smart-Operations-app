-- supabase/migrations/0002_rls_policies.sql
--
-- ⚠️ STATUS: written and internally reviewed against Supabase's documented
-- RLS patterns, NOT executed or tested against a live database — there is no
-- Supabase project or local Postgres reachable from this environment. Before
-- trusting these policies with real data: run them against a real (ideally
-- staging, not production) Supabase project and write a few manual test
-- queries as two different users to confirm each policy behaves as intended
-- — see documentation-supabase/RLS_POLICIES.md for a suggested test plan.
--
-- Pattern used throughout: two SECURITY DEFINER helper functions
-- (is_staff_or_admin, is_admin) so policies read cleanly as
-- "own row OR is_staff_or_admin()" instead of repeating a subquery on
-- profiles in every single policy.

create function public.is_staff_or_admin()
returns boolean
language sql security definer stable
set search_path = public
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and role in ('staff', 'admin')
  );
$$;

create function public.is_admin()
returns boolean
language sql security definer stable
set search_path = public
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and role = 'admin'
  );
$$;

-- Enable RLS on every table. A table with no policies and RLS enabled
-- denies all access by default — nothing here is "publicly readable unless
-- intentional" (the CMS table is the one deliberate exception, see below).
alter table public.profiles enable row level security;
alter table public.projects enable row level security;
alter table public.bookings enable row level security;
alter table public.payments enable row level security;
alter table public.notifications enable row level security;
alter table public.tickets enable row level security;
alter table public.documents enable row level security;
alter table public.chat_messages enable row level security;
alter table public.equipment enable row level security;
alter table public.expenses enable row level security;
alter table public.cms enable row level security;
alter table public.audit_logs enable row level security;

-- ============================================================
-- PROFILES
-- ============================================================
create policy "profiles: own row or staff/admin can select" on public.profiles
  for select using (id = auth.uid() or public.is_staff_or_admin());

create policy "profiles: own row can update own basic fields" on public.profiles
  for update using (id = auth.uid()) with check (id = auth.uid());

create policy "profiles: admin can update any profile" on public.profiles
  for update using (public.is_admin());

create policy "profiles: admin can delete" on public.profiles
  for delete using (public.is_admin());
-- No insert policy for profiles: rows are created only by the
-- on_auth_user_created trigger (SECURITY DEFINER), never directly by a
-- client request — matches the original app's behavior where registration
-- goes through a single controlled code path, not an arbitrary insert.

-- ============================================================
-- PROJECTS
-- ============================================================
create policy "projects: client sees own, staff/admin see all" on public.projects
  for select using (client_id = auth.uid() or public.is_staff_or_admin());

create policy "projects: staff/admin can insert" on public.projects
  for insert with check (public.is_staff_or_admin());

create policy "projects: staff/admin can update" on public.projects
  for update using (public.is_staff_or_admin());

create policy "projects: admin can delete" on public.projects
  for delete using (public.is_admin());

-- ============================================================
-- BOOKINGS
-- ============================================================
create policy "bookings: client sees/creates own, staff/admin see all" on public.bookings
  for select using (client_id = auth.uid() or public.is_staff_or_admin());

create policy "bookings: client can create own" on public.bookings
  for insert with check (client_id = auth.uid());

create policy "bookings: staff/admin can update status" on public.bookings
  for update using (public.is_staff_or_admin());

create policy "bookings: owner or staff/admin can delete (cancel)" on public.bookings
  for delete using (client_id = auth.uid() or public.is_staff_or_admin());

-- ============================================================
-- PAYMENTS
-- ============================================================
create policy "payments: client sees own, staff/admin see all" on public.payments
  for select using (client_id = auth.uid() or public.is_staff_or_admin());

create policy "payments: staff/admin can record" on public.payments
  for insert with check (public.is_staff_or_admin());

create policy "payments: staff/admin can update" on public.payments
  for update using (public.is_staff_or_admin());

-- ============================================================
-- NOTIFICATIONS
-- ============================================================
create policy "notifications: own or broadcast, or staff/admin" on public.notifications
  for select using (user_id = auth.uid() or user_id is null or public.is_staff_or_admin());

create policy "notifications: staff/admin can create" on public.notifications
  for insert with check (public.is_staff_or_admin());

create policy "notifications: recipient can mark read" on public.notifications
  for update using (user_id = auth.uid() or public.is_staff_or_admin());

-- ============================================================
-- TICKETS
-- ============================================================
create policy "tickets: client sees own, staff/admin see all" on public.tickets
  for select using (client_id = auth.uid() or public.is_staff_or_admin());

create policy "tickets: client can create own" on public.tickets
  for insert with check (client_id = auth.uid());

create policy "tickets: owner can reply, staff/admin can reply and change status" on public.tickets
  for update using (client_id = auth.uid() or public.is_staff_or_admin());

create policy "tickets: staff/admin can delete" on public.tickets
  for delete using (public.is_staff_or_admin());

-- A client can update their own ticket (e.g. append a reply via the
-- `replies` jsonb column) but must not be able to change `status` — only
-- staff/admin should resolve/reopen a ticket. RLS alone is row-level, not
-- column-level, so this is enforced with a trigger rather than a policy.
create function public.prevent_client_status_change()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if not public.is_staff_or_admin() and new.status is distinct from old.status then
    raise exception 'Only staff or admin can change a ticket''s status';
  end if;
  return new;
end;
$$;
create trigger tickets_guard_status before update on public.tickets
  for each row execute procedure public.prevent_client_status_change();

-- ============================================================
-- DOCUMENTS (metadata table — see 0003_storage_buckets.sql for the actual
-- file-bytes policies on storage.objects)
-- ============================================================
create policy "documents: client sees own, staff/admin see all" on public.documents
  for select using (client_id = auth.uid() or public.is_staff_or_admin());

create policy "documents: any authenticated user can record their own upload" on public.documents
  for insert with check (uploaded_by = auth.uid());

create policy "documents: staff/admin can delete" on public.documents
  for delete using (public.is_staff_or_admin());

-- ============================================================
-- CHAT MESSAGES
-- ============================================================
create policy "chat: client sees own thread, staff/admin see all" on public.chat_messages
  for select using (client_id = auth.uid() or public.is_staff_or_admin());

create policy "chat: client can message own thread, staff/admin any thread" on public.chat_messages
  for insert with check (client_id = auth.uid() or public.is_staff_or_admin());

-- ============================================================
-- EQUIPMENT & EXPENSES — staff/admin only, no client access at all
-- ============================================================
create policy "equipment: staff/admin only" on public.equipment
  for all using (public.is_staff_or_admin()) with check (public.is_staff_or_admin());

create policy "expenses: staff/admin only" on public.expenses
  for all using (public.is_staff_or_admin()) with check (public.is_staff_or_admin());

-- ============================================================
-- CMS — the one deliberately public table (site content is meant to be
-- readable by anyone, including the logged-out marketing/login screen)
-- ============================================================
create policy "cms: anyone can read" on public.cms
  for select using (true);

create policy "cms: admin can update" on public.cms
  for update using (public.is_admin());

-- ============================================================
-- AUDIT LOGS — admin only, matching the original app's requireRole("admin")
-- (staff could see everything else but never audit logs)
-- ============================================================
create policy "audit_logs: admin only" on public.audit_logs
  for select using (public.is_admin());
-- Inserts happen via SECURITY DEFINER functions / Edge Functions (see
-- EDGE_FUNCTIONS.md), not directly from client requests, so there is
-- deliberately no insert policy for authenticated/anon roles here.
