-- supabase/migrations/0003_storage_buckets.sql
--
-- ⚠️ STATUS: written, not executed — same caveat as the other migrations.
--
-- ⚠️ SCOPE NOTE: the migration prompt suggested four buckets (profile-images,
-- documents, uploads, public-assets). Only ONE — "documents" — corresponds
-- to an actual existing feature (borehole reports / water-test results /
-- contracts, currently handled by backend/routes/documents.js and
-- backend/lib/storage/). There is no profile-picture upload, no generic
-- "uploads" concept separate from documents, and no public marketing-asset
-- serving anywhere in the current app. Per "do not invent features," this
-- migration creates only the bucket the app actually uses. If you want the
-- other three later, they're straightforward to add following this same
-- pattern — see documentation-supabase/STORAGE.md.

insert into storage.buckets (id, name, public)
values ('documents', 'documents', false)
on conflict (id) do nothing;

-- storage.objects already has RLS enabled by default in Supabase. Policies
-- below assume documents are stored at a path like
-- "{client_id}/{document_id}.{ext}" — i.e. the client's uuid is the first
-- path segment — so ownership can be checked from the path itself without
-- an extra join. See STORAGE.md for the exact path convention the upload
-- Edge Function (supabase/functions/upload-document) uses.

create policy "documents bucket: owner or staff/admin can read"
  on storage.objects for select
  using (
    bucket_id = 'documents'
    and (
      (storage.foldername(name))[1] = auth.uid()::text
      or public.is_staff_or_admin()
    )
  );

create policy "documents bucket: owner can upload to their own folder"
  on storage.objects for insert
  with check (
    bucket_id = 'documents'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

create policy "documents bucket: staff/admin can delete"
  on storage.objects for delete
  using (bucket_id = 'documents' and public.is_staff_or_admin());
