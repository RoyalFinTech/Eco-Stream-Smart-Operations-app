# Database & Migrations — Verification Report

## Current production database: JSON file store (`lib/db.js`)

This is what the app actually runs on today. There is no "migration" system in the traditional sense — the schema is implicit in the JS code, not versioned SQL files. What *was* tested, because it's the closest meaningful equivalent to "does upgrading/redeploying lose data":

**Test performed:** started the server, created a new client record via the live API, killed the process (simulating a redeploy), restarted it *without* deleting the data file, and re-queried.

**Result: verified pass.**
- The new record survived the restart.
- The two seeded demo clients were **not duplicated** — `lib/seed.js` only seeds a collection when it's empty (`seedIfEmpty`), confirmed by checking the client list showed exactly 3 records (2 seed + 1 new), not 5.
- Total client count matched exactly before and after restart.

**What this does and doesn't prove:** it proves a simple process restart is safe. It does **not** prove anything about concurrent writes from multiple server instances (the JSON file has no locking across processes — documented as a known limitation in the original architecture notes) or about surviving a corrupted write mid-save. The atomic-write pattern (write to `.tmp`, then rename) in `lib/db.js` protects against a *partial* write corrupting the file, but this wasn't separately stress-tested (e.g., killing the process mid-write) in this pass.

## PostgreSQL + Prisma migration: NOT verified — re-confirmed still blocked

Re-checked rather than assumed stale from the last report:

```
$ npm view zod version
npm error 403 403 Forbidden - GET https://registry.npmjs.org/zod

$ cat < /dev/null > /dev/tcp/localhost/5432
bash: connect: Connection refused — no Postgres server reachable

$ npx prisma --version
npm error 403 403 Forbidden - GET https://registry.npmjs.org/prisma
```

Both blockers from the prior migration work are still in effect: no npm registry access, no reachable PostgreSQL server, and now also confirmed no cached/offline copy of the `prisma` CLI exists anywhere on this system. Nothing about this status has changed since it was first reported — `prisma migrate dev` and `prisma validate` genuinely cannot be run here.

**What was re-checked instead, as a substitute for CLI validation:**
- Manually cross-referenced every model name in `prisma/schema.prisma` against every `CREATE TABLE` statement in `prisma/migrations/001_init/migration.sql` — all 13 models are present in both files, in the same order, with matching names. This is a real structural consistency check, but it is **not** a substitute for `prisma validate`, which also checks field types, relation integrity, and constraint syntax against Prisma's actual parser.
- Confirmed (by reading `server.js`) that none of this is wired into the running application — `DATABASE_URL` has zero effect today (see `ENVIRONMENT_VARIABLES.md`).

**Bottom line:** the schema and migration SQL are believed correct based on manual review and structural cross-checking, but have never been executed, and that distinction matters — manual review catches naming mismatches, not every class of error a real parser or database would catch.

## What would need to happen to actually verify this

1. Get npm registry access (or download the `prisma` and `@prisma/client` packages some other way and install from local files) and a reachable Postgres instance (managed — RDS, Supabase, Neon, Render Postgres — or self-hosted).
2. Run `npx prisma validate` — pure syntax/type checking, no data risk.
3. Run `npx prisma migrate dev --name init` against a **disposable/staging** database first, never production, and let Prisma generate its own migration rather than trusting the hand-authored one in this repo.
4. Only then proceed with the route-by-route conversion described in `POSTGRES_MIGRATION.md`.

None of this can be done from within this environment. It is listed as a blocker, not a task I attempted and partially completed.
