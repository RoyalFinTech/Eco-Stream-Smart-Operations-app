# Production Deployment Checklist

Each item is tagged **[Verified]** (tested this pass or a prior pass against a live server — see linked reports), **[Verified gap]** (tested and confirmed to be a real problem, not yet fixed), or **[Unverified/Assumption]** (standard practice, not testable from this sandbox).

## Before you deploy

- [ ] **[Verified — enforced by the app itself]** Generate and set a real `JWT_SECRET`. The previous hardcoded fallback has been removed; the app now refuses to start in production without this set (tested) and only auto-generates a temporary one in development (tested, with a visible warning). See `ENVIRONMENT_VARIABLES.md`.
- [ ] **[Verified]** Set `ALLOWED_ORIGINS` to your real portal domains. Confirmed a non-whitelisted origin is correctly refused when this is set.
- [ ] **[Unverified/Assumption]** Change or remove the seeded demo accounts (`admin@ecostream.gm` / `Admin@1234` etc.) — the credentials are printed in multiple docs in this repo, so anyone who reads them has admin access until you do this. I can't do this for you since it requires deciding on real replacement accounts.
- [ ] **[Verified]** Decide your `RATE_LIMIT_MAX`. Default (120/min/IP) was verified to trigger correctly; raise it if you expect legitimate burst traffic (e.g., a shared office IP), lower it if you want tighter brute-force protection.
- [ ] **[Verified]** Leave `STORAGE_PROVIDER=local` unless you have separately, actually tested S3/R2/Supabase against a real account — this project's cloud storage code has never completed a real request to any of those services (sandbox network restrictions blocked the only attempt made). See `ENVIRONMENT_VARIABLES.md`.

## Deploying

- [ ] **[Verified]** The backend needs no `npm install` step — confirmed by extracting the packaged zip fresh and running `node server.js` with nothing else.
- [ ] **[Unverified/Assumption]** Follow `DEPLOYMENT_GUIDE.md` for your chosen host (Render config included and structurally reviewed, not live-deployed from here).
- [ ] **[Verified gap]** After deploying, run the step-4 smoke test in `DEPLOYMENT_GUIDE.md` (login + document upload) — confirmed this is necessary because an invalid `STORAGE_PROVIDER` value does **not** fail at startup, only on first document operation.
- [ ] **[Unverified/Assumption]** Confirm the persistent disk/volume is actually mounted at the database path on your host — I can't click through your hosting provider's UI, but I did confirm (see `DATABASE_MIGRATIONS_STATUS.md`) that a plain process restart with the data file intact preserves all data correctly.

## Data safety

- [ ] **[Verified]** Data survives a normal process restart without duplication or loss — tested directly (create record → kill process → restart → confirm record present, seed not re-run).
- [ ] **[Unverified]** Data survives a *host-level* failure (disk loss, container rebuilt from a fresh image) — this depends entirely on your hosting platform's disk/volume persistence, which is outside what this sandbox can test. Treat backups as mandatory, not optional, until you've personally confirmed your host's volume survives a redeploy.
- [ ] **[Verified]** `scripts/backup.sh` runs correctly and produces a timestamped backup of the database file and any uploaded documents — actually executed and its output inspected.
- [ ] **[Unverified/Assumption]** Schedule `scripts/backup.sh` via cron or your host's scheduled-jobs feature. I wrote and tested the script; I can't set up a cron job on infrastructure that doesn't exist yet.

## Security

- [ ] **[Verified]** Security headers (CSP, X-Frame-Options, etc.), CORS whitelist, and rate limiting are all live and were tested with real requests hitting real thresholds, not just present in code.
- [ ] **[Verified]** Role-based access control (client vs staff vs admin) was re-tested exhaustively this pass across every restricted endpoint — see prior `PRODUCTION_READINESS_REPORT.md`.
- [ ] **[Verified gap]** No rate limiting on password reset requests specifically beyond the global limit — acceptable at small scale, worth revisiting if abuse appears.
- [ ] **[Unverified/Assumption]** No email service is connected. Password reset and email verification return their tokens directly in the API response instead of emailing them. This is clearly labeled in the API responses (`devResetToken`, `devEmailVerificationToken`) so it can't be mistaken for a working email flow, but it means **anyone who can call the API can reset any account's password if they know the email address**, until a real email provider is wired up. Treat this as a hard blocker for any deployment with real, non-trusted users.

## After launch

- [ ] **[Unverified/Assumption]** Monitor `/api/health` from an uptime service.
- [ ] **[Verified]** Structured JSON logs are written to `backend/logs/app.log` at `LOG_LEVEL=info` or more verbose — confirmed the level filtering works correctly in both directions (raising and lowering verbosity).
- [ ] **[Unverified/Assumption]** Set up log rotation or shipping if you expect meaningful volume — `logs/app.log` currently grows unbounded (append-only, no rotation built in). Not tested at volume.

## Explicit go/no-go blockers

These are the items I would not personally consider a production system "ready" against, based only on what's been verified:

1. **No email service** — password reset is a real security hole without one (see above).
2. ~~`JWT_SECRET` unset — silent, no warning~~ **[Fixed]** — the app now enforces this itself in production and warns clearly in development.
3. **Demo credentials still active and documented in this repo.**
4. **Cloud storage (S3/R2/Supabase) selected without having personally tested it** — the code has never completed a real request to any of these services.
