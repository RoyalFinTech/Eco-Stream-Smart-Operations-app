# Remaining Blockers — Consolidated

One place for every verified blocker found across this audit. Full evidence for each is in the linked document; this file is the summary, not the source of truth.

## Hard blockers (do not launch to real users without addressing these)

1. **No email service.** Password reset and email verification work end-to-end but return their tokens directly in the API response instead of emailing them. **[Verified]** — tested the full reset flow using the returned token. Risk: anyone who can call the API and knows an account's email can reset that account's password. → `ENVIRONMENT_VARIABLES.md`, `PRODUCTION_DEPLOYMENT_CHECKLIST.md`.
2. ~~`JWT_SECRET` defaults to a hardcoded value with zero warning if unset.~~ **[Fixed and verified]** — `lib/auth.js` no longer has a hardcoded fallback. The app now refuses to start in production without a real `JWT_SECRET` (tested: throws a clear error), and generates a random per-process secret with a visible warning in development (tested: logs the warning, works normally). See `ENVIRONMENT_VARIABLES.md`.
3. **Demo admin/staff/client credentials are documented in plain text across this project's own docs.** Not a code defect, but a real access risk until changed. → `PRODUCTION_DEPLOYMENT_CHECKLIST.md`.

## Verified gaps (real, but lower severity — workarounds documented)

4. **`STORAGE_PROVIDER` is validated at first use, not at startup.** **[Verified]** — set it to an invalid value and confirmed the server starts and reports healthy anyway; the error only surfaces on the first document upload/download attempt. Workaround: the deploy-time smoke test in `DEPLOYMENT_GUIDE.md` catches this immediately instead of waiting for a user to hit it.
5. **The JSON datastore has no cross-process locking.** Fine for the single-process deployment this is built for; would need addressing (most likely by finishing the Postgres migration) before running multiple server instances behind a load balancer. Not exercised under concurrent load this pass.
6. **`backend/logs/app.log` grows unbounded** — no rotation built in. Not tested at any real volume.

## Cannot be verified from this environment (not "broken" — genuinely untestable here)

7. **PostgreSQL + Prisma migration.** Schema and migration SQL are written and manually cross-checked for consistency, but have never executed against a real database — no reachable Postgres server, no npm registry access (re-confirmed this pass, not assumed from a prior report). → `DATABASE_MIGRATIONS_STATUS.md`.
8. **S3 / Cloudflare R2 / Supabase storage providers.** Code runs and fails cleanly when it can't reach these services, but no real request has ever completed against any of them — no credentials, and this sandbox's own network restrictions blocked the one live attempt made. → `ENVIRONMENT_VARIABLES.md`.
9. **Actual hosting-platform behavior** (Render/Railway/DigitalOcean disk persistence across redeploys, HTTPS provisioning, custom domains). The application-level restart/data-persistence behavior was verified; the hosting platform's own infrastructure guarantees were not, since no such infrastructure exists in this sandbox.
10. **CDN-loaded assets** (Google Fonts in both portals, Swagger UI in `api-docs.html`). Blocked by this sandbox's own network policy — standard CDN usage, expected to work in any normal browser with internet access, but not something rendered/confirmed here.

## What is fully verified and not a blocker

Auth (including refresh tokens, lockout, sessions), role-based access control across all three roles, every core business workflow (bookings → projects → payments → invoices, tickets, chat, documents, notifications, CMS, audit logs), security headers, rate limiting, CORS whitelisting, structured logging, graceful shutdown, and data persistence across a process restart — all independently re-tested this pass with real requests against a live server. Details in `PRODUCTION_READINESS_REPORT.md` and the environment-variable-specific tests in `ENVIRONMENT_VARIABLES.md`.
